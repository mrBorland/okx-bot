def farm_openblock():
    print("Фармінг OpenBlock...")
