def farm_taskon():
    print("Фармінг TaskOn...")
