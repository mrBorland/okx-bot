def farm_port3():
    print("Фармінг Port3...")
