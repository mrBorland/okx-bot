
import time
from utils import check_balance
from farm_layer3 import farm_layer3
from farm_zealy import farm_zealy
from farm_taskon import farm_taskon
from farm_questn import farm_questn
from farm_openblock import farm_openblock
from farm_port3 import farm_port3

def farm_all():
    print("Запуск OKX фермера...")
    while True:
        check_balance()
        farm_layer3()
        farm_zealy()
        farm_taskon()
        farm_questn()
        farm_openblock()
        farm_port3()
        time.sleep(3600)  # перевірка раз на годину

if __name__ == "__main__":
    farm_all()
