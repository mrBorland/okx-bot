def farm_layer3():
    print("Фармінг Layer3...")
