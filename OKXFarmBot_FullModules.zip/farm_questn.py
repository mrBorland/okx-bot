def farm_questn():
    print("Фармінг QuestN...")
