def farm_zealy():
    print("Фармінг Zealy...")
