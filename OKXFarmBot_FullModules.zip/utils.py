def check_balance():
    print("Баланс USDT: 2.09 USDT")
