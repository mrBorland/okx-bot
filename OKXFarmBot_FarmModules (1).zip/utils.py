# Тут можуть бути допоміжні функції
def check_balance():
    return "2.09 USDT"
