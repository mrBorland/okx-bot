import time

def farm_okx():
    print("Запуск OKX фермера...")
    while True:
        print("Перевірка балансу...")
        print("Баланс USDT:
	2.09 USDT")
        time.sleep(60)

if __name__ == "__main__":
    farm_okx()
